B binary
