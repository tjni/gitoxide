int f(int x, int y)
{
  if (x == 0)
  {
    return y;
  }
  return x;
}

int g(size_t u)
{
  while (u > 34)
  {
    u--;
  }
  return u;
}
